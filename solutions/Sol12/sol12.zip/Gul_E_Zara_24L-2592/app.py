import streamlit as st
import pickle
import numpy as np

with open("knn_model.pkl", "rb") as f:
    model = pickle.load(f)

st.title("Customer Purchase Prediction App")
st.write("This app predicts whether a customer is likely to make a purchase.")
st.write("Adjust the inputs below and click Predict.")


# Input Widgets
session_duration = st.slider("Session Duration", 0, 50, 25)
pages_visited = st.slider("Pages Visited", 1, 20, 12)
bounce_rate = st.slider("Bounce Rate", 0, 100, 25)
time_on_site = st.number_input("Time on Site (minutes)", 0, 1000, 600)

device = st.radio("Device Type", ["Mobile", "Desktop", "Tablet"])
previous_purchase = st.radio("Previous Purchase", ["Yes", "No"])
region = st.radio("Region", ["North", "South", "East", "West"])

# Device Type
device_mobile = 1 if device == "Mobile" else 0
device_tablet = 1 if device == "Tablet" else 0

# Previous Purchase
prev_yes = 1 if previous_purchase == "Yes" else 0

reg_north = 1 if region == "North" else 0
reg_south = 1 if region == "South" else 0
reg_west = 1 if region == "West" else 0

input_data = np.array([
    session_duration,
    pages_visited,
    time_on_site,        
    bounce_rate,         
    device_mobile,
    device_tablet,
    prev_yes,
    reg_north,          
    reg_south,
    reg_west            
]).reshape(1, -1)

# Prediction
if st.button("Predict"):
    prediction = model.predict(input_data)[0]

    if prediction == 1:
        st.success("The customer is likely to purchase.")
    else:
        st.error("The customer is not likely to purchase.")
